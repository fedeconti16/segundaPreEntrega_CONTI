from setuptools import setup

setup(
    name= "modeloClientes",
    version= "1.0",
    description= "Genera nuevos clientes",
    author= "Federico", 
    author_email= "fedeconti16@gmail.com",
    packages= ["modulos"] 
)